Dvalve needs to be in the workspace.

Dvalve = 2*sqrt(5e-5/pi);